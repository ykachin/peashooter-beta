<template>
  <div>
    <hr />
    <p class="teamname"> &emsp;&emsp;&copy;2020wandou.com, fzu豌豆射手队 </p>
    <a href="" >&emsp;关于我们&emsp;</a>
    <a href="" >&emsp;联系我们&emsp;</a>
  </div>
</template>

<script>
  export default {
    name: 'myfoot',
    data:function() {
      return{ }
    },
  }
</script>

<style scoped>
  .teamname{
    margin: 0px;
    font-size: medium;
    float: left;
  }
  a{
    font-size: medium;
    text-decoration: none;
    float: right;
  }
</style>
