<template>
  <div>
    <myhead></myhead>
    <div id="hello" style="width:0px;height:0px;margin-top: 50px">

      <div id="base" class="">

        <!-- Unnamed (动态面板) -->
        <div id="u0" class="ax_default">
          <div id="state0" class="panel_state"  >
            <div id="u0_state0_content" class="panel_state_content">

              <!-- Unnamed (动态面板) -->
              <div id="u1" class="ax_default">
                <div id="m1_state0" class="panel_state" data-label="State1" style="">
                  <div id="m1_state0_content" class="panel_state_content">



                    <!-- Unnamed (矩形) -->
                    <div id="u2" class="ax_default box_1">
                      <img id="u2_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=494167576,3517200638&fm=58">
                      <div id="u2_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u3" class="ax_default box_1">
                      <img id="u3_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=778783410,527677881&fm=58&app=83&f=JPEG?w=400&h=533&s=EEF1E05EDB10584F0AF1F847030020F1">
                      <div id="u3_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u4" class="ax_default box_1">
                      <img id="u4_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=558808288,4201467168&fm=58&s=E6E0F058CF41494F4355676B0300F074">
                      <div id="u4_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u5" class="ax_default box_1">
                      <img id="u5_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1015626475,3623922484&fm=58&s=B23A7084089280D4DE7E1D84030070C8">
                      <div id="u5_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u6" class="ax_default box_1">
                      <img id="u6_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=3922757577,1976860482&fm=58&s=77BB1DC754054AEC5CBDF17303008071">
                      <div id="u6_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u7" class="ax_default box_1">
                      <img id="u7_div" class="" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3154490288,944524743&fm=58&s=67D25F85CA031AD4643541160100D0C3">
                      <div id="u7_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u8" class="ax_default box_1">
                      <img id="u8_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=3454659850,1279319584&fm=58&s=1C07177C1DD0DC491E58BCD60100E0B1">
                      <div id="u8_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u9" class="ax_default box_1">
                      <img id="u9_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1688676229,1191966103&fm=58&app=83&f=JPEG?w=150&h=200&s=D33F39C454AB04B8EF8D2C17030010CA">
                      <div id="u9_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u10" class="ax_default box_1">
                      <div id="u10_div" class=""></div>
                      <div id="u10_text" class="text ">
                        <p><span id="a9">庆余年</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u11" class="ax_default box_1">
                      <div id="u11_div" class=""></div>
                      <div id="u11_text" class="text ">
                        <p><span id="a10">切尔诺贝利</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u12" class="ax_default box_1">
                      <div id="u12_div" class=""></div>
                      <div id="u12_text" class="text ">
                        <p><span id="a11">锦衣天下</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u13" class="ax_default box_1">
                      <div id="u13_div" class=""></div>
                      <div id="u13_text" class="text ">
                        <p><span id="a12">我是余欢水</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u14" class="ax_default box_1">
                      <div id="u14_div" class=""></div>
                      <div id="u14_text" class="text ">
                        <p><span id="a13">延禧宫略</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u15" class="ax_default box_1">
                      <div id="u15_div" class=""></div>
                      <div id="u15_text" class="text ">
                        <p><span id="a14">权力的游戏</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u16" class="ax_default box_1">
                      <div id="u16_div" class=""></div>
                      <div id="u16_text" class="text ">
                        <p><span id="a15">西部世界</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u17" class="ax_default box_1">
                      <div id="u17_div" class=""></div>
                      <div id="u17_text" class="text ">
                        <p><span id="a16">精英律师</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m1_state1" class="panel_state" data-label="State2" style="visibility: hidden;">
                  <div id="m1_state1_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u18" class="ax_default box_1">
                      <img id="u18_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=558808288,4201467168&fm=58&s=E6E0F058CF41494F4355676B0300F074">
                      <div id="u18_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u19" class="ax_default box_1">
                      <img id="u18_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=2069485848,1297134864&fm=58&app=83&f=JPEG?w=400&h=533&s=5700D70092623ABEF4357D870300A082">
                      <div id="u19_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u20" class="ax_default box_1">
                      <img id="u18_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=3450385683,574316072&fm=58&app=83&f=JPEG?w=150&h=200&s=E08BBA550C534DD80099416003007075">
                      <div id="u20_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u21" class="ax_default box_1">
                      <img id="u18_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1968001582,65192213&fm=58&app=83&f=JPEG?w=150&h=200&s=E9925F9C48434AC8480CB0EB03007070">
                      <div id="u21_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u22" class="ax_default box_1">
                      <img id="u18_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=3562361595,769326677&fm=58&s=75A49E51CE196BCE5AA01D510300C08A">
                      <div id="u22_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u23" class="ax_default box_1">
                      <img id="u18_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1688676229,1191966103&fm=58&app=83&f=JPEG?w=150&h=200&s=D33F39C454AB04B8EF8D2C17030010CA">
                      <div id="u23_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u24" class="ax_default box_1">
                      <img id="u18_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=117231139,867154527&fm=58">
                      <div id="u24_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u25" class="ax_default box_1">
                      <img id="u18_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=1127756151,778441511&fm=58&s=5105DD145DFAD7F11D156CCC0300E0A2">
                      <div id="u25_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u26" class="ax_default box_1">
                      <div id="u26_div" class=""></div>
                      <div id="u26_text" class="text ">
                        <p><span>锦衣天下</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u27" class="ax_default box_1">
                      <div id="u27_div" class=""></div>
                      <div id="u27_text" class="text ">
                        <p><span>陈情令</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u28" class="ax_default box_1">
                      <div id="u28_div" class=""></div>
                      <div id="u28_text" class="text ">
                        <p><span>绿水青山带笑颜</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u29" class="ax_default box_1">
                      <div id="u29_div" class=""></div>
                      <div id="u29_text" class="text ">
                        <p><span>远方的山楂树</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u30" class="ax_default box_1">
                      <div id="u30_div" class=""></div>
                      <div id="u30_text" class="text ">
                        <p><span>东宫</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u31" class="ax_default box_1">
                      <div id="u31_div" class=""></div>
                      <div id="u31_text" class="text ">
                        <p><span>精英律师</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u32" class="ax_default box_1">
                      <div id="u32_div" class=""></div>
                      <div id="u32_text" class="text ">
                        <p><span>明国奇探</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u33" class="ax_default box_1">
                      <div id="u33_div" class=""></div>
                      <div id="u33_text" class="text ">
                        <p><span>倚天屠龙记</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m1_state2" class="panel_state" data-label="State3" style="visibility: hidden;">
                  <div id="m1_state2_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u34" class="ax_default box_1">
                      <img id="u34_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=3090517813,1044695273&fm=58&app=83&f=JPEG?w=300&h=400&s=AFFC768680850CEF37380CB903009012">
                      <div id="u34_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u35" class="ax_default box_1">
                      <img id="u35_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=3321106162,712864406&fm=58&s=D9D614C6523293CC5AC4BDBE03001005">
                      <div id="u35_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u36" class="ax_default box_1">
                      <img id="u35_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=820898571,3650166448&fm=58&s=D895B2BA48D245F14B1C00DF030010F6">
                      <div id="u36_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u37" class="ax_default box_1">
                      <img id="u35_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=360665770,499104320&fm=58&app=83&f=JPEG?w=300&h=400&s=1CA60A9B42E0E4EA5E3C9EEC0300D035">
                      <div id="u37_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u38" class="ax_default box_1">
                      <img id="u35_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=3129280674,2994687005&fm=58&s=3570168B54011AF4110188BC0300C095">
                      <div id="u38_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u39" class="ax_default box_1">
                      <img id="u35_div" class="" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=404696042,3412828163&fm=58">
                      <div id="u39_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u40" class="ax_default box_1">
                      <img id="u35_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=2640512833,1977096915&fm=58&app=83&f=JPEG?w=400&h=533&s=9680CEA646A38EF9548995A60300B009">
                      <div id="u40_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u41" class="ax_default box_1">
                      <img id="u35_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=3680147761,4082433121&fm=58&s=C4AC46FA51066D5D42A7527F03001074">
                      <div id="u41_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u42" class="ax_default box_1">
                      <div id="u42_div" class=""></div>
                      <div id="u42_text" class="text ">
                        <p><span>声临其境</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u43" class="ax_default box_1">
                      <div id="u43_div" class=""></div>
                      <div id="u43_text" class="text ">
                        <p><span>等着我</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u44" class="ax_default box_1">
                      <div id="u44_div" class=""></div>
                      <div id="u44_text" class="text ">
                        <p><span>快乐大本营</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u45" class="ax_default box_1">
                      <div id="u45_div" class=""></div>
                      <div id="u45_text" class="text ">
                        <p><span>我们的乐队</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u46" class="ax_default box_1">
                      <div id="u46_div" class=""></div>
                      <div id="u46_text" class="text ">
                        <p><span>开门大吉</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u47" class="ax_default box_1">
                      <div id="u47_div" class=""></div>
                      <div id="u47_text" class="text ">
                        <p><span>天天向上</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u48" class="ax_default box_1">
                      <div id="u48_div" class=""></div>
                      <div id="u48_text" class="text ">
                        <p><span>王牌对王牌</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u49" class="ax_default box_1">
                      <div id="u49_div" class=""></div>
                      <div id="u49_text" class="text ">
                        <p><span>健康之路</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m1_state3" class="panel_state" data-label="State4" style="visibility: hidden;">
                  <div id="m1_state3_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u50" class="ax_default box_1">
                      <img id="u50_div" class="" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3310895657,3315209064&fm=58&app=83&f=JPEG?w=150&h=200&s=BE002ECB1E238AC40ACF10360300505A">
                      <div id="u50_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u51" class="ax_default box_1">
                      <img id="u50_div" class="" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3187597499,2690165625&fm=58&s=7E1609C75F090ADC58D069360300F001">
                      <div id="u51_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u52" class="ax_default box_1">
                      <img id="u50_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=4049863420,2128417759&fm=58&app=83&f=JPEG?w=150&h=200&s=145357308431E7843A5BE9CD0300F0B6">
                      <div id="u52_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u53" class="ax_default box_1">
                      <img id="u50_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=2768229352,1148497361&fm=58&app=83&f=JPEG?w=400&h=533&s=EC702DC6C62292F41EFCCC1F0300D093">
                      <div id="u53_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u54" class="ax_default box_1">
                      <img id="u50_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=2538189423,1605950232&fm=58&app=83&f=JPEG?w=400&h=533&s=97161DC70263B8FF4C5454B303007011">
                      <div id="u54_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u55" class="ax_default box_1">
                      <img id="u50_div" class="" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=1603360520,1896742795&fm=58&s=BEED468604C280FA1AABF52C0300F019">
                      <div id="u55_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u56" class="ax_default box_1">
                      <img id="u50_div" class="" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1699980841,1872414250&fm=58&s=5DB428D45E472B4F4081ED190300E0C2">
                      <div id="u56_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u57" class="ax_default box_1">
                      <img id="u50_div" class="" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=740567100,1231384853&fm=58&s=EE300DC70724BEFA56F401270300E042">
                      <div id="u57_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u58" class="ax_default box_1">
                      <div id="u58_div" class=""></div>
                      <div id="u58_text" class="text ">
                        <p><span>我们这一天</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u59" class="ax_default box_1">
                      <div id="u59_div" class=""></div>
                      <div id="u59_text" class="text ">
                        <p><span>巴瑞</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u60" class="ax_default box_1">
                      <div id="u60_div" class=""></div>
                      <div id="u60_text" class="text ">
                        <p><span>良医</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u61" class="ax_default box_1">
                      <div id="u61_div" class=""></div>
                      <div id="u61_text" class="text ">
                        <p><span>后裔</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u62" class="ax_default box_1">
                      <div id="u62_div" class=""></div>
                      <div id="u62_text" class="text ">
                        <p><span>继承之战</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u63" class="ax_default box_1">
                      <div id="u63_div" class=""></div>
                      <div id="u63_text" class="text ">
                        <p><span>破产姐妹</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u64" class="ax_default box_1">
                      <div id="u64_div" class=""></div>
                      <div id="u64_text" class="text ">
                        <p><span>风骚律师</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u65" class="ax_default box_1">
                      <div id="u65_div" class=""></div>
                      <div id="u65_text" class="text ">
                        <p><span>生活大爆炸</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m1_state4" class="panel_state" data-label="State5" style="visibility: hidden;">
                  <div id="m1_state4_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u66" class="ax_default box_1">
                      <div id="u66_div" class=""></div>
                      <div id="u66_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u67" class="ax_default box_1">
                      <div id="u67_div" class=""></div>
                      <div id="u67_text" class="text ">
                        <p><span>5</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u68" class="ax_default box_1">
                      <div id="u68_div" class=""></div>
                      <div id="u68_text" class="text ">
                        <p><span>3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u69" class="ax_default box_1">
                      <div id="u69_div" class=""></div>
                      <div id="u69_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u70" class="ax_default box_1">
                      <div id="u70_div" class=""></div>
                      <div id="u70_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u71" class="ax_default box_1">
                      <div id="u71_div" class=""></div>
                      <div id="u71_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u72" class="ax_default box_1">
                      <div id="u72_div" class=""></div>
                      <div id="u72_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u73" class="ax_default box_1">
                      <div id="u73_div" class=""></div>
                      <div id="u73_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u74" class="ax_default box_1">
                      <div id="u74_div" class=""></div>
                      <div id="u74_text" class="text ">
                        <p><span>电视剧1 </span><span style="color:#DAA51A;">8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u75" class="ax_default box_1">
                      <div id="u75_div" class=""></div>
                      <div id="u75_text" class="text ">
                        <p><span>电视剧2 </span><span style="color:#DAA51A;">7.9</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u76" class="ax_default box_1">
                      <div id="u76_div" class=""></div>
                      <div id="u76_text" class="text ">
                        <p><span>电视剧3 </span><span style="color:#DAA51A;">5.6</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u77" class="ax_default box_1">
                      <div id="u77_div" class=""></div>
                      <div id="u77_text" class="text ">
                        <p><span>电视剧4 </span><span style="color:#DAA51A;">6.6</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u78" class="ax_default box_1">
                      <div id="u78_div" class=""></div>
                      <div id="u78_text" class="text ">
                        <p><span>电视剧1 </span><span style="color:#DAA51A;">8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u79" class="ax_default box_1">
                      <div id="u79_div" class=""></div>
                      <div id="u79_text" class="text ">
                        <p><span>电视剧1 </span><span style="color:#DAA51A;">8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u80" class="ax_default box_1">
                      <div id="u80_div" class=""></div>
                      <div id="u80_text" class="text ">
                        <p><span>电视剧1 </span><span style="color:#DAA51A;">8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u81" class="ax_default box_1">
                      <div id="u81_div" class=""></div>
                      <div id="u81_text" class="text ">
                        <p><span>电视剧1 </span><span style="color:#DAA51A;">8.1</span></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (动态面板) -->
              <div id="u82" class="ax_default">
                <div id="m82_state0" class="panel_state" data-label="State1" >
                  <div id="m82_state0_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u83" class="ax_default box_1">
                      <img  id="u83_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=4234663971,2658748769&fm=58&app=83&f=JPEG?w=400&h=533&s=DF5414C642EA86FE30FDE82C03004051"/>
                      <div id="u83_text" class="text">

                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u84" class="ax_default box_1">
                      <img id="u84_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=1774374002,4136586970&fm=58&app=83&f=JPEG?w=300&h=400&s=63AA9F474465490D0EB636730300D07F"/>
                      <div id="u84_text" class="text">

                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u85" class="ax_default box_1">
                      <img id="u85_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=141395650,1410461605&fm=58&app=83&f=JPEG?w=300&h=400&s=254099469F309DDE1EEDA49D0300C082/">
                      <div id="u85_text" class="text">

                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u86" class="ax_default box_1">
                      <img id="u86_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=623207089,455845934&fm=58&app=83&f=JPEG?w=400&h=533&s=728D07AE6042D0E79CAF8DA10300704B">
                      <div id="u86_text" class="text">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u87" class="ax_default box_1">
                      <img id="u87_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3038023691,2568317562&fm=58&app=83&f=JPEG?w=400&h=533&s=1F0A2FC84102BCFE1AC40500030070D3">
                      <div id="u87_text" class="text">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u88" class="ax_default box_1">
                      <img id="u88_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=3397677588,3071591638&fm=58&app=83&f=JPEG?w=400&h=533&s=FAF009C44A33A6DC0479F1130300F0CA">
                      <div id="u88_text" class="text">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u89" class="ax_default box_1">
                      <img id="u89_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3831863255,600067371&fm=58&app=83&f=JPEG?w=400&h=533&s=9340D7A20AE39ACC52D9E524030070C3">
                      <div id="u89_text" class="text">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u90" class="ax_default box_1">
                      <img id="u90_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=949064346,3514604057&fm=58&app=83&f=JPEG?w=400&h=533&s=C8D6EA0BCE3824949898950A0100A091">
                      <div id="u90_text" class="text">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u91" class="ax_default box_1">
                      <div id="u91_div" class=""></div>
                      <div id="u91_text" class="text ">
                        <p><span class="upload_biaoti" id="a1">牧羊女大冒险 </span><span class="upload_pingfen"  style="color:#DAA51A;"> 8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u92" class="ax_default box_1">
                      <div id="u92_div" class=""></div>
                      <div id="u92_text" class="text ">
                        <p><span class="upload_biaoti" id="a2">第一头牛 </span><span  class="upload_pingfen"  style="color:#DAA51A;"> 7.9</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u93" class="ax_default box_1">
                      <div id="u93_div" class=""></div>
                      <div id="u93_text" class="text ">
                        <p><span class="upload_biaoti" id="a3">096 </span><span class="upload_pingfen" style="color:#DAA51A;"> 8.3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u94" class="ax_default box_1">
                      <div id="u94_div" class=""></div>
                      <div id="u94_text" class="text ">
                        <p><span class="upload_biaoti" id="a4">真雄起</span><span class="upload_pingfen" style="color:#DAA51A;"> 7.9</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u95" class="ax_default box_1">
                      <div id="u95_div" class=""></div>
                      <div id="u95_text" class="text ">
                        <p><span class="upload_biaoti" id="a5">欧耶芭蕾</span><span class="upload_pingfen" style="color:#DAA51A;"> 7.3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u96" class="ax_default box_1">
                      <div id="u96_div" class=""></div>
                      <div id="u96_text" class="text ">
                        <p><span class="upload_biaoti" id="a6">翻译疑云</span><span class="upload_pingfen" style="color:#DAA51A;"> 7.2</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u97" class="ax_default box_1">
                      <div id="u97_div" class=""></div>
                      <div id="u97_text" class="text ">
                        <p><span class="upload_biaoti" id="a7">我想藏起来</span><span class="upload_pingfen" style="color:#DAA51A;"> 7.4</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u98" class="ax_default box_1">
                      <div id="u98_div" class=""></div>
                      <div id="u98_text" class="text ">
                        <p><span class="upload_biaoti" id="a8">列夫·朗道:退变</span><span class="upload_pingfen" style="color:#DAA51A;"> 8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (图片 ) -->



                    <!-- Unnamed (图片 ) -->
                    <div id="u100" class="ax_default image">
                      <div id="u100_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m82_state1" class="panel_state" data-label="State2" style="visibility: hidden;">
                  <div id="m82_state1_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u101" class="ax_default box_1">
                      <img id="u101_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1995132370,2416037737&fm=58&app=83&f=JPEG?w=300&h=400&s=ADD07E84C08390F4D4DD59B603005010">
                      <div id="u101_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u102" class="ax_default box_1">
                      <img id="u102_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=2721338182,1892654165&fm=58&app=83&f=JPEG?w=200&h=266&s=A4C0954EC01238751671C5080300A013">
                      <div id="u102_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u103" class="ax_default box_1">
                      <img id="u103_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1301289550,599929985&fm=58&app=83&f=JPEG?w=400&h=533&s=1EB043860E1302D4551C63A903007086">
                      <div id="u103_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u104" class="ax_default box_1">
                      <img id="u104_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=665585189,2635653064&fm=58&app=83&f=JPEG?w=400&h=533&s=2E1209CB46E2B14F48DC8C2B03007041">
                      <div id="u104_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u105" class="ax_default box_1">
                      <img id="u105_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3799128446,3984384322&fm=58&app=83&f=JPEG?w=400&h=533&s=B000DA14ED116BDC0B314DC10300E0A2">
                      <div id="u105_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u106" class="ax_default box_1">
                      <img id="u106_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=2194932477,2744133998&fm=58&app=83&f=JPEG?w=400&h=533&s=EAA224C5E0D673DE860185B403001023">
                      <div id="u106_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u107" class="ax_default box_1">
                      <img id="u107_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1212063745,1636221305&fm=58&app=83&f=JPEG?w=300&h=400&s=DD6029C45AFA90DE527CF4810300E091">
                      <div id="u107_text" class="text ">
                        <p><span></span>img</p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u108" class="ax_default box_1">
                      <img id="u108_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=3817490574,3259262617&fm=58&app=83&f=JPEG?w=400&h=533&s=B79B7587801173CC18B5C9E10300F001">
                      <div id="u108_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u109" class="ax_default box_1">
                      <div id="u109_div" class=""></div>
                      <div id="u109_text" class="text ">
                        <p><span id="a17">伏虎武松</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <div id="u110" class="ax_default box_1">
                      <div id="u110_div" class=""></div>
                      <div id="u110_text" class="text ">
                        <p><span id="a18">奔跑吧甜心</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u111" class="ax_default box_1">
                      <div id="u111_div" class=""></div>
                      <div id="u111_text" class="text ">
                        <p><span id="a19">如何培养一个女孩</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u112" class="ax_default box_1">
                      <div id="u112_div" class=""></div>
                      <div id="u112_text" class="text ">
                        <p><span id="a20">波斯语课程</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u113" class="ax_default box_1">
                      <div id="u113_div" class=""></div>
                      <div id="u113_text" class="text ">
                        <p><span id="a21">军民大生产</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u114" class="ax_default box_1">
                      <div id="u114_div" class=""></div>
                      <div id="u114_text" class="text ">
                        <p><span id="a22">在街上</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u115" class="ax_default box_1">
                      <div id="u115_div" class=""></div>
                      <div id="u115_text" class="text ">
                        <p><span id="a23">欢乐的精灵</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u116" class="ax_default box_1">
                      <div id="u116_div" class=""></div>
                      <div id="u116_text" class="text ">
                        <p><span id="a24">梦想之马</span><span style="color:#DAA51A;"></span></p>
                      </div>
                    </div>



                    <!-- Unnamed (图片 ) -->
                    <div id="u118" class="ax_default image">

                      <div id="u118_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m82_state2" class="panel_state" data-label="State3" style="visibility: hidden;">
                  <div id="m82_state2_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u119" class="ax_default box_1">
                      <img id="u119_div" class="upload_div" src="https://dss0.baidu.com/-Po3dSag_xI4khGko9WTAnF6hhy/image/pic/item/738b4710b912c8fc384d01a5f0039245d6882118.jpg">
                      <div id="u119_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u120" class="ax_default box_1">
                      <img id="u120_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=787652361,1329536808&fm=58&s=1BD5F7A644014CED18FFB3730300F079">
                      <div id="u120_text" class="text ">
                        <p><span>test3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u121" class="ax_default box_1">
                      <img id="u121_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=700343164,1237684525&fm=58&s=B6049C4FCB5716CC697D11360300D040">
                      <div id="u121_text" class="text ">
                        <p><span>3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u122" class="ax_default box_1">
                      <img id="u122_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=1621893621,2065019442&fm=58&s=FD42EC17132366A02C59CDDD0300C020">
                      <div id="u122_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u123" class="ax_default box_1">
                      <img id="u123_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=3916000477,2656043904&fm=58&s=C56493469F76A4DC664D918803003012">
                      <div id="u123_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u124" class="ax_default box_1">
                      <img id="u124_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=514943120,583237469&fm=58&s=C0308D72032E7CA87AE040E10300F0A2">
                      <div id="u124_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u125" class="ax_default box_1">
                      <img id="u125_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=942128250,1285103462&fm=58&s=1A3D798654CA84FC481E61A60300F012">
                      <div id="u125_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u126" class="ax_default box_1">
                      <img id="u126_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1921409476,1980655018&fm=58&s=4860A244C2F83D9E70B097990300C097">
                      <div id="u126_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u127" class="ax_default box_1">
                      <div id="u127_div" class=""></div>
                      <div id="u127_text" class="text ">
                        <p><span>我不是药神</span><span style="color:#DAA51A;"> 9.0</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u128" class="ax_default box_1">
                      <div id="u128_div" class=""></div>
                      <div id="u128_text" class="text ">
                        <p><span>三傻大闹好莱坞</span><span style="color:#DAA51A;"> 9.2</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u129" class="ax_default box_1">
                      <div id="u129_div" class=""></div>
                      <div id="u129_text" class="text ">
                        <p><span>肖申克的救赎</span><span style="color:#DAA51A;"> 9.7</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u130" class="ax_default box_1">
                      <div id="u130_div" class=""></div>
                      <div id="u130_text" class="text ">
                        <p><span>霸王别姬</span><span style="color:#DAA51A;"> 9.6</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u131" class="ax_default box_1">
                      <div id="u131_div" class=""></div>
                      <div id="u131_text" class="text ">
                        <p><span>千与千寻</span><span style="color:#DAA51A;"> 9.4</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u132" class="ax_default box_1">
                      <div id="u132_div" class=""></div>
                      <div id="u132_text" class="text ">
                        <p><span>阿甘正传</span><span style="color:#DAA51A;"> 9.5</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u133" class="ax_default box_1">
                      <div id="u133_div" class=""></div>
                      <div id="u133_text" class="text ">
                        <p><span>这个杀手不太冷</span><span style="color:#DAA51A;"> 9.4</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u134" class="ax_default box_1">
                      <div id="u134_div" class=""></div>
                      <div id="u134_text" class="text ">
                        <p><span>星际穿越</span><span style="color:#DAA51A;"> 9.3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (图片 ) -->
                    <div id="u135" class="ax_default image">

                      <div id="u135_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (图片 ) -->
                    <div id="u136" class="ax_default image">

                      <div id="u136_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m82_state3" class="panel_state" data-label="State4" style="visibility: hidden;">
                  <div id="m82_state3_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u137" class="ax_default box_1">
                      <img id="u137_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=1506509424,1731787174&fm=58&s=C7A0B3E2D842B0CC4D314001030070D1#">
                      <div id="u137_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u138" class="ax_default box_1">
                      <img id="u138_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=1575423528,1615172077&fm=58&s=172069A0C852BFE50639DC15030080C2">
                      <div id="u138_text" class="text ">
                        <p><span>test4</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u139" class="ax_default box_1">
                      <img id="u139_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=2975901083,2518363767&fm=58">
                      <div id="u139_text" class="text ">
                        <p><span>3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u140" class="ax_default box_1">
                      <img id="u140_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3992808686,3494530648&fm=58&app=83&f=JPEG?w=150&h=200&s=FE381EC75AA380DA902280AD0300D04A">
                      <div id="u140_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u141" class="ax_default box_1">
                      <img id="u141_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=3347214178,1265969800&fm=58&s=BA931DCFD456C1CE4818383C0300805A">
                      <div id="u141_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u142" class="ax_default box_1">
                      <img id="u142_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=2902217750,1702414084&fm=58&s=D78EEEAE4453CBED3C8B5CB30300E00B#">
                      <div id="u142_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u143" class="ax_default box_1">
                      <img id="u143_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=2615390465,2692784211&fm=58&s=7A1157841853E2C41A1E299C030070EA">
                      <div id="u143_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u144" class="ax_default box_1">
                      <img id="u144_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=2277429237,2853658307&fm=58&s=DCBC67DA8272A5CE0AAC1F3C0300C054">
                      <div id="u144_text" class="text ">
                        <p><span>1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u145" class="ax_default box_1">
                      <div id="u145_div" class=""></div>
                      <div id="u145_text" class="text ">
                        <p><span>湄公河行动</span><span style="color:#DAA51A;"> 8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u146" class="ax_default box_1">
                      <div id="u146_div" class=""></div>
                      <div id="u146_text" class="text ">
                        <p><span>战狼</span><span style="color:#DAA51A;"> 7.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u147" class="ax_default box_1">
                      <div id="u147_div" class=""></div>
                      <div id="u147_text" class="text ">
                        <p><span>少年的你</span><span style="color:#DAA51A;"> 8.3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u148" class="ax_default box_1">
                      <div id="u148_div" class=""></div>
                      <div id="u148_text" class="text ">
                        <p><span>我和我的祖国</span><span style="color:#DAA51A;"> 7.3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u149" class="ax_default box_1">
                      <div id="u149_div" class=""></div>
                      <div id="u149_text" class="text ">
                        <p><span>红海行动</span><span style="color:#DAA51A;"> 8.3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u150" class="ax_default box_1">
                      <div id="u150_div" class=""></div>
                      <div id="u150_text" class="text ">
                        <p><span>唐人街探案2</span><span style="color:#DAA51A;"> 6.7</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u151" class="ax_default box_1">
                      <div id="u151_div" class=""></div>
                      <div id="u151_text" class="text ">
                        <p><span>舒克贝塔</span><span style="color:#DAA51A;"> 8.5</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u152" class="ax_default box_1">
                      <div id="u152_div" class=""></div>
                      <div id="u152_text" class="text ">
                        <p><span>罗小黑战记</span><span style="color:#DAA51A;"> 8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (图片 ) -->
                    <div id="u153" class="ax_default image">

                      <div id="u153_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (图片 ) -->
                    <div id="u154" class="ax_default image">

                      <div id="u154_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m82_state4" class="panel_state" data-label="State5" style="visibility: hidden;">
                  <div id="m82_state4_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u155" class="ax_default box_1">
                      <img id="u155_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=4216794451,768777121&fm=58&app=83&f=JPEG?w=400&h=533&s=BD21A019475243D4C6A5A6C6030070BF">
                      <div id="u155_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u156" class="ax_default box_1">
                      <img id="u156_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=4068672002,929365249&fm=58&app=83&f=JPEG?w=400&h=533&s=9B9144840E1A6ECE0936D6410300D0F9">
                      <div id="u156_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u157" class="ax_default box_1">
                      <img  id="u157_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=793199502,3041177597&fm=58&s=EABB1BC7A4634ABC6BA0D9320300C013">
                      <div id="u157_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u158" class="ax_default box_1">
                      <img  id="u158_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=3084197689,862650034&fm=58&s=DBBCB7E258132EC434B836390300D04D">
                      <div id="u158_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u159" class="ax_default box_1">
                      <img  id="u159_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=521423730,1733614869&fm=58&s=CD202CD710C00AEF5192DD7403005079">
                      <div id="u159_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u160" class="ax_default box_1">
                      <img  id="u160_div" class="upload_div" src="https://dss2.baidu.com/6ONYsjip0QIZ8tyhnq/it/u=3736708205,3624361310&fm=58&s=55C5C2A6CA3288DC14729EAB0300E007">
                      <div id="u160_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u161" class="ax_default box_1">
                      <img  id="u161_div" class="upload_div" src="https://dss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=3542027998,910174279&fm=58&s=BF7A7F834C3389FD008DE51A01001092">
                      <div id="u161_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u162" class="ax_default box_1">
                      <img  id="u162_div" class="upload_div" src="https://dss0.baidu.com/6ONWsjip0QIZ8tyhnq/it/u=2605386252,3229575353&fm=58&s=7C0AE61E4A4A55472AB37AFD0300C02C">
                      <div id="u162_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u163" class="ax_default box_1">
                      <div id="u163_div" class=""></div>
                      <div id="u163_text" class="text ">
                        <p><span class="upload_div_img">雪人奇缘</span><span style="color:#DAA51A;"> 7.3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u164" class="ax_default box_1">
                      <div id="u164_div" class=""></div>
                      <div id="u164_text" class="text ">
                        <p><span >绿皮书</span><span style="color:#DAA51A;"> 8.9</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u165" class="ax_default box_1">
                      <div id="u165_div" class=""></div>
                      <div id="u165_text" class="text ">
                        <p><span >终结者:黑暗命运</span><span style="color:#DAA51A;"> 6.9</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u166" class="ax_default box_1">
                      <div id="u166_div" class=""></div>
                      <div id="u166_text" class="text ">
                        <p><span >我在雨中等你</span><span style="color:#DAA51A;"> 8.2</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u167" class="ax_default box_1">
                      <div id="u167_div" class=""></div>
                      <div id="u167_text" class="text ">
                        <p><span >头号玩家</span><span style="color:#DAA51A;"> 8.7</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u168" class="ax_default box_1">
                      <div id="u168_div" class=""></div>
                      <div id="u168_text" class="text ">
                        <p><span >复仇者联盟3:无限战争</span><span style="color:#DAA51A;"> 8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u169" class="ax_default box_1">
                      <div id="u169_div" class=""></div>
                      <div id="u169_text" class="text ">
                        <p><span>海王</span><span style="color:#DAA51A;"> 7.6</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u170" class="ax_default box_1">
                      <div id="u170_div" class=""></div>
                      <div id="u170_text" class="text ">
                        <p><span>波西米亚狂想曲</span><span style="color:#DAA51A;"> 8.1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (图片 ) -->
                    <div id="u171" class="ax_default image">

                      <div id="u171_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (图片 ) -->
                    <div id="u172" class="ax_default image">

                      <div id="u172_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u173" class="ax_default box_1">
                <div id="u173_div" class=""></div>
                <div id="u173_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u174" class="ax_default box_1">
                <div id="u174_div" class=""></div>
                <div id="u174_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u175" class="ax_default box_1">
                <div id="u175_div" class=""></div>
                <div id="u175_text" class="text ">
                  <p><span>电影</span></p>
                </div>
              </div>

              <!-- dytab1 (矩形) -->
              <div id="dy176" class="ax_default box_1 selected" data-label="dytab1" selectiongroup="1" style="cursor:pointer">
                <div id="u176_div" class="selected"></div>
                <div id="u176_text" class="text ">
                  <p><span>热门</span></p>
                </div>
              </div>

              <!-- dytab2 (矩形) -->
              <div id="dy177" class="ax_default box_1" data-label="dytab2" selectiongroup="1" style="cursor:pointer">
                <div id="u177_div" class=""></div>
                <div id="u177_text" class="text ">
                  <p><span>最新</span></p>
                </div>
              </div>

              <!-- dytab3 (矩形) -->
              <div id="dy178" class="ax_default box_1" data-label="dytab3" selectiongroup="1" style="cursor:pointer">
                <div id="u178_div" class=""></div>
                <div id="u178_text" class="text ">
                  <p><span>高分</span></p>
                </div>
              </div>

              <!-- dytab4 (矩形) -->
              <div id="dy179" class="ax_default box_1" data-label="dytab4" selectiongroup="1" style="cursor:pointer">
                <div id="u179_div" class=""></div>
                <div id="u179_text" class="text ">
                  <p><span>华语</span></p>
                </div>
              </div>

              <!-- dytab5 (矩形) -->
              <div id="dy180" class="ax_default box_1" data-label="dytab5" selectiongroup="1" style="cursor:pointer">
                <div id="u180_div" class=""></div>
                <div id="u180_text" class="text ">
                  <p><span>欧美</span></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u181" class="ax_default line">
                <img id="u181_img" class="img " src="static/resources/images/page_1/u181.svg"/>
                <div id="u181_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u182" class="ax_default box_1">
                <div id="u182_div" class=""></div>
                <div id="u182_text" class="text ">
                  <p><span>口碑榜</span></p>
                </div>
              </div>



              <!-- Unnamed (矩形) -->
              <div id="u184" class="ax_default box_1">
                <div id="u184_div" class=""></div>
                <div id="u184_text" class="text ">
                  <p><span>1.肖申克的救赎</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u185" class="ax_default box_1">
                <div id="u185_div" class=""></div>
                <div id="u185_text" class="text ">
                  <p><span>2.霸王别姬</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u186" class="ax_default box_1">
                <div id="u186_div" class=""></div>
                <div id="u186_text" class="text ">
                  <p><span>3.阿甘正传</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u187" class="ax_default box_1">
                <div id="u187_div" class=""></div>
                <div id="u187_text" class="text ">
                  <p><span>4.千与千寻</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u188" class="ax_default box_1">
                <div id="u188_div" class=""></div>
                <div id="u188_text" class="text ">
                  <p><span>5.我不是药神</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u189" class="ax_default box_1">
                <div id="u189_div" class=""></div>
                <div id="u189_text" class="text ">
                  <p><span>电视剧</span></p>
                </div>
              </div>

              <!-- dstab1 (矩形) -->
              <div id="dy190" class="ax_default box_1 selected" data-label="dstab1" selectiongroup="2" style="cursor:pointer;color:black">
                <div id="u190_div" class="selected"></div>
                <div id="u190_text" class="text ">
                  <p><span>热门</span></p>
                </div>
              </div>

              <!-- dstab2 (矩形) -->
              <div id="dy191" class="ax_default box_1"  data-label="dstab1" selectiongroup="2" style="cursor:pointer">
                <div id="u191_div" class=""></div>
                <div id="u191_text" class="text ">
                  <p><span>国产剧</span></p>
                </div>
              </div>

              <!-- dstab3 (矩形) -->
              <div id="dy192" class="ax_default box_1" data-label="dstab3" selectiongroup="2"  style="cursor:pointer">
                <div id="u192_div" class=""></div>
                <div id="u192_text" class="text ">
                  <p><span>综艺</span></p>
                </div>
              </div>

              <!-- dstab4 (矩形) -->
              <div id="dy193" class="ax_default box_1" data-label="dstab4" selectiongroup="2" style="cursor:pointer">
                <div id="u193_div" class=""></div>
                <div id="u193_text" class="text ">
                  <p><span>美剧</span></p>
                </div>
              </div>



              <!-- Unnamed (线段) -->
              <div id="u195" class="ax_default line">
                <img id="u195_img" class="img " src="static/resources/images/page_1/u195.svg"/>
                <div id="u195_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u196" class="ax_default image">
                <img id="u196_img" class="img " src="static/resources/images/page_1/u196.png"/>
                <div id="u196_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u197" class="ax_default line">
                <img id="u197_img" class="img " src="static/resources/images/page_1/u197.svg"/>
                <div id="u197_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u198" class="ax_default box_1">
                <div id="u198_div" class=""></div>
                <div id="u198_text" class="text ">
                  <p><span>合作联系</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u199" class="ax_default box_1">
                <img id="u199_img" class="img " src="static/resources/images/page_1/u199.svg"/>
                <div id="u199_text" class="text ">
                  <p><span>电影合作邮箱:xxxx@qq.com</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u200" class="ax_default box_1">
                <img id="u200_img" class="img " src="static/resources/images/page_1/u200.svg"/>
                <div id="u200_text" class="text ">
                  <p><span>电视剧合作邮箱:wandousheshou@qq.com</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u201" class="ax_default box_1">
                <img id="u201_img" class="img " src="static/resources/images/page_1/u201.svg"/>
                <div id="u201_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u202" class="ax_default box_1">
                <div id="u202_div" class=""></div>
                <div id="u202_text" class="text ">
                  <p><span>关注我们</span></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u203" class="ax_default line">
                <img id="u203_img" class="img " src="static/resources/images/page_1/u197.svg"/>
                <div id="u203_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u204" class="ax_default image">
                <img id="u204_img" class="img " src="static/resources/images/page_1/u204.png"/>
                <div id="u204_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u205" class="ax_default image">
                <img id="u205_img" class="img " src="static/resources/images/page_1/u205.png"/>
                <div id="u205_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u206" class="ax_default box_1">
                <div id="u206_div" class=""></div>
                <div id="u206_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->

            </div>
          </div>
          <div id="state1" class="panel_state"  >
            <div id="u0_state1_content" class="panel_state_content">

              <!-- Unnamed (动态面板) -->
              <div id="u208" class="ax_default">
                <div id="u208_state0" class="panel_state" data-label="State1" style="">
                  <div id="u208_state0_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u209" class="ax_default box_1">
                      <img id="u209_div" class="" src="http://img4.kuwo.cn/star/starheads/300/1/27/2191880246.jpg">
                      <div id="u209_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u210" class="ax_default box_1">
                      <img id="u209_div" class="" src="http://img1.kuwo.cn/star/starheads/300/10/6/294045140.jpg">
                      <div id="u209_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u211" class="ax_default box_1">
                      <img id="u209_div" class="" src="http://img1.kuwo.cn/star/starheads/300/49/32/1945019798.jpg">
                      <div id="u209_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u212" class="ax_default box_1">
                      <img id="u209_div" class="" src="http://img4.kuwo.cn/star/starheads/300/17/65/1359494068.jpg">
                      <div id="u209_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u213" class="ax_default box_1">
                      <img id="u209_div" class="" src="http://img3.kuwo.cn/star/starheads/300/47/68/3668920800.jpg">
                      <div id="u209_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u214" class="ax_default box_1">
                      <img id="u209_div" class="" src="http://img2.kuwo.cn/star/starheads/300/4/85/16817798.jpg">
                      <div id="u209_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>
                    <!-- Unnamed (矩形) -->
                    <div id="u226" class="ax_default box_1">
                      <div id="u226_div" class=""></div>
                      <div id="u226_text" class="text ">
                        <p><span>邓紫棋</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u215" class="ax_default box_1">
                      <img id="u215_img" class="img " src="static/resources/images/page_1/u215.svg"/>
                      <div id="u215_text" class="text ">
                        <p><span>周杰伦</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u216" class="ax_default box_1">
                      <div id="u216_div" class=""></div>
                      <div id="u216_text" class="text ">
                        <p><span>Alan Walker</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u217" class="ax_default box_1">
                      <div id="u217_div" class=""></div>
                      <div id="u217_text" class="text ">
                        <p><span>The Chainsmokers</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u218" class="ax_default box_1">
                      <div id="u218_div" class=""></div>
                      <div id="u218_text" class="text ">
                        <p><span>Beyond</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u219" class="ax_default box_1">
                      <div id="u219_div" class=""></div>
                      <div id="u219_text" class="text ">
                        <p><span>BIGBANG</span></p>
                      </div>
                    </div>




                    <!-- Unnamed (形状) -->
                    <div id="u227" class="ax_default icon">

                      <div id="u227_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u228" class="ax_default icon">

                      <div id="u228_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u229" class="ax_default icon">

                      <div id="u229_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u230" class="ax_default icon">

                      <div id="u230_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u231" class="ax_default icon">

                      <div id="u231_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u232" class="ax_default icon">

                      <div id="u232_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="u208_state1" class="panel_state" data-label="State2" style="visibility: hidden;">
                  <div id="u208_state1_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u233" class="ax_default box_1">
                      <div id="u233_div" class=""></div>
                      <div id="u233_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u234" class="ax_default box_1">
                      <div id="u234_div" class=""></div>
                      <div id="u234_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u235" class="ax_default box_1">
                      <div id="u235_div" class=""></div>
                      <div id="u235_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u236" class="ax_default box_1">
                      <div id="u236_div" class=""></div>
                      <div id="u236_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u237" class="ax_default box_1">
                      <div id="u237_div" class=""></div>
                      <div id="u237_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u238" class="ax_default box_1">
                      <div id="u238_div" class=""></div>
                      <div id="u238_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u239" class="ax_default box_1">
                      <img id="u239_img" class="img " src="static/resources/images/page_1/u215.svg"/>
                      <div id="u239_text" class="text ">
                        <p><span>音乐2</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u240" class="ax_default box_1">
                      <div id="u240_div" class=""></div>
                      <div id="u240_text" class="text ">
                        <p><span>音乐3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u241" class="ax_default box_1">
                      <div id="u241_div" class=""></div>
                      <div id="u241_text" class="text ">
                        <p><span>音乐4</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u242" class="ax_default box_1">
                      <div id="u242_div" class=""></div>
                      <div id="u242_text" class="text ">
                        <p><span>音乐5</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u243" class="ax_default box_1">
                      <div id="u243_div" class=""></div>
                      <div id="u243_text" class="text ">
                        <p><span>音乐6</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u244" class="ax_default box_1">
                      <img id="u244_img" class="img " src="static/resources/images/page_1/u220.svg"/>
                      <div id="u244_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u245" class="ax_default box_1">
                      <div id="u245_div" class=""></div>
                      <div id="u245_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u246" class="ax_default box_1">
                      <div id="u246_div" class=""></div>
                      <div id="u246_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u247" class="ax_default box_1">
                      <div id="u247_div" class=""></div>
                      <div id="u247_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u248" class="ax_default box_1">
                      <div id="u248_div" class=""></div>
                      <div id="u248_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u249" class="ax_default box_1">
                      <div id="u249_div" class=""></div>
                      <div id="u249_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u250" class="ax_default box_1">
                      <div id="u250_div" class=""></div>
                      <div id="u250_text" class="text ">
                        <p><span>音乐1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u251" class="ax_default icon">
                      <img id="u251_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u251_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u252" class="ax_default icon">
                      <img id="u252_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u252_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u253" class="ax_default icon">
                      <img id="u253_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u253_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u254" class="ax_default icon">
                      <img id="u254_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u254_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u255" class="ax_default icon">
                      <img id="u255_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u255_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u256" class="ax_default icon">
                      <img id="u256_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u256_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="u208_state2" class="panel_state" data-label="State3" style="visibility: hidden;">
                  <div id="u208_state2_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u257" class="ax_default box_1">
                      <div id="u257_div" class=""></div>
                      <div id="u257_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u258" class="ax_default box_1">
                      <div id="u258_div" class=""></div>
                      <div id="u258_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u259" class="ax_default box_1">
                      <div id="u259_div" class=""></div>
                      <div id="u259_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u260" class="ax_default box_1">
                      <div id="u260_div" class=""></div>
                      <div id="u260_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u261" class="ax_default box_1">
                      <div id="u261_div" class=""></div>
                      <div id="u261_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u262" class="ax_default box_1">
                      <div id="u262_div" class=""></div>
                      <div id="u262_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u263" class="ax_default box_1">
                      <img id="u263_img" class="img " src="static/resources/images/page_1/u215.svg"/>
                      <div id="u263_text" class="text ">
                        <p><span>音乐2</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u264" class="ax_default box_1">
                      <div id="u264_div" class=""></div>
                      <div id="u264_text" class="text ">
                        <p><span>音乐3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u265" class="ax_default box_1">
                      <div id="u265_div" class=""></div>
                      <div id="u265_text" class="text ">
                        <p><span>音乐4</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u266" class="ax_default box_1">
                      <div id="u266_div" class=""></div>
                      <div id="u266_text" class="text ">
                        <p><span>音乐5</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u267" class="ax_default box_1">
                      <div id="u267_div" class=""></div>
                      <div id="u267_text" class="text ">
                        <p><span>音乐6</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u268" class="ax_default box_1">
                      <img id="u268_img" class="img " src="static/resources/images/page_1/u220.svg"/>
                      <div id="u268_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u269" class="ax_default box_1">
                      <div id="u269_div" class=""></div>
                      <div id="u269_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u270" class="ax_default box_1">
                      <div id="u270_div" class=""></div>
                      <div id="u270_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u271" class="ax_default box_1">
                      <div id="u271_div" class=""></div>
                      <div id="u271_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u272" class="ax_default box_1">
                      <div id="u272_div" class=""></div>
                      <div id="u272_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u273" class="ax_default box_1">
                      <div id="u273_div" class=""></div>
                      <div id="u273_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u274" class="ax_default box_1">
                      <div id="u274_div" class=""></div>
                      <div id="u274_text" class="text ">
                        <p><span>音乐1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u275" class="ax_default icon">
                      <img id="u275_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u275_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u276" class="ax_default icon">
                      <img id="u276_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u276_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u277" class="ax_default icon">
                      <img id="u277_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u277_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u278" class="ax_default icon">
                      <img id="u278_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u278_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u279" class="ax_default icon">
                      <img id="u279_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u279_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u280" class="ax_default icon">
                      <img id="u280_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u280_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="u208_state3" class="panel_state" data-label="State4" style="visibility: hidden;">
                  <div id="u208_state3_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u281" class="ax_default box_1">
                      <div id="u281_div" class=""></div>
                      <div id="u281_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u282" class="ax_default box_1">
                      <div id="u282_div" class=""></div>
                      <div id="u282_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u283" class="ax_default box_1">
                      <div id="u283_div" class=""></div>
                      <div id="u283_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u284" class="ax_default box_1">
                      <div id="u284_div" class=""></div>
                      <div id="u284_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u285" class="ax_default box_1">
                      <div id="u285_div" class=""></div>
                      <div id="u285_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u286" class="ax_default box_1">
                      <div id="u286_div" class=""></div>
                      <div id="u286_text" class="text ">
                        <p><span>音乐封面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u287" class="ax_default box_1">
                      <img id="u287_img" class="img " src="static/resources/images/page_1/u215.svg"/>
                      <div id="u287_text" class="text ">
                        <p><span>音乐2</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u288" class="ax_default box_1">
                      <div id="u288_div" class=""></div>
                      <div id="u288_text" class="text ">
                        <p><span>音乐3</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u289" class="ax_default box_1">
                      <div id="u289_div" class=""></div>
                      <div id="u289_text" class="text ">
                        <p><span>音乐4</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u290" class="ax_default box_1">
                      <div id="u290_div" class=""></div>
                      <div id="u290_text" class="text ">
                        <p><span>音乐5</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u291" class="ax_default box_1">
                      <div id="u291_div" class=""></div>
                      <div id="u291_text" class="text ">
                        <p><span>音乐6</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u292" class="ax_default box_1">
                      <img id="u292_img" class="img " src="static/resources/images/page_1/u220.svg"/>
                      <div id="u292_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u293" class="ax_default box_1">
                      <div id="u293_div" class=""></div>
                      <div id="u293_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u294" class="ax_default box_1">
                      <div id="u294_div" class=""></div>
                      <div id="u294_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u295" class="ax_default box_1">
                      <div id="u295_div" class=""></div>
                      <div id="u295_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u296" class="ax_default box_1">
                      <div id="u296_div" class=""></div>
                      <div id="u296_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u297" class="ax_default box_1">
                      <div id="u297_div" class=""></div>
                      <div id="u297_text" class="text ">
                        <p><span>作者1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u298" class="ax_default box_1">
                      <div id="u298_div" class=""></div>
                      <div id="u298_text" class="text ">
                        <p><span>音乐1</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u299" class="ax_default icon">
                      <img id="u299_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u299_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u300" class="ax_default icon">
                      <img id="u300_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u300_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u301" class="ax_default icon">
                      <img id="u301_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u301_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u302" class="ax_default icon">
                      <img id="u302_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u302_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u303" class="ax_default icon">
                      <img id="u303_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u303_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u304" class="ax_default icon">
                      <img id="u304_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u304_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Unnamed (动态面板) -->
              <div id="u305" class="ax_default">
                <div id="m305_state0" class="panel_state" data-label="State1" style="">
                  <div id="m305_state0_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u306" class="ax_default flow_shape">
                      <div id="u306_div" class=""></div>
                      <div id="u306_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u307" class="ax_default box_1">
                      <img id="u307_div" class="" src="static/resources/images/y2.jpg" >
                      <div id="u307_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u308" class="ax_default box_1">
                      <img id="u308_div" class="" src="static/resources/images/y3.jpg" >
                      <div id="u308_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u309" class="ax_default box_1">
                      <img id="u309_div" class="" src="static/resources/images/y4.jpg" >
                      <div id="u309_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u310" class="ax_default box_1">
                      <img id="u310_div" class="" src="static/resources/images/y5.jpg" >
                      <div id="u310_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u311" class="ax_default box_1">
                      <img id="u311_div" class="" src="static/resources/images/y6.jpg" >
                      <div id="u311_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u312" class="ax_default box_1">
                      <img id="u312_div" class="" src="static/resources/images/y7.jpg" >
                      <div id="u312_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u313" class="ax_default box_1">
                      <img id="u313_img" class="img " src="static/resources/images/page_1/u215.svg"/>
                      <div id="u313_text" class="text ">
                        <p><span id="y2">夜空中最亮的星</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u314" class="ax_default box_1">
                      <div id="u314_div" class=""></div>
                      <div id="u314_text" class="text ">
                        <p><span id="y3">Love&Desire</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u315" class="ax_default box_1">
                      <div id="u315_div" class=""></div>
                      <div id="u315_text" class="text ">
                        <p><span id="y4">新世界</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u316" class="ax_default box_1">
                      <div id="u316_div" class=""></div>
                      <div id="u316_text" class="text ">
                        <p><span id="y5">音乐5</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u317" class="ax_default box_1">
                      <div id="u317_div" class=""></div>
                      <div id="u317_text" class="text ">
                        <p><span id="y6">音乐6</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u318" class="ax_default box_1">
                      <img id="u318_img" class="img " src="static/resources/images/page_1/u220.svg"/>
                      <div id="u318_text" class="text ">
                        <p><span>苏慧伦</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u319" class="ax_default box_1">
                      <div id="u319_div" class=""></div>
                      <div id="u319_text" class="text ">
                        <p><span>王俊凯/萧敬腾/谢霆锋</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u320" class="ax_default box_1">
                      <div id="u320_div" class=""></div>
                      <div id="u320_text" class="text ">
                        <p><span>周震南 Vin</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u321" class="ax_default box_1">
                      <div id="u321_div" class=""></div>
                      <div id="u321_text" class="text ">
                        <p><span>华晨宇</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u322" class="ax_default box_1">
                      <div id="u322_div" class=""></div>
                      <div id="u322_text" class="text ">
                        <p><span>(여자)아이들,(G)I-DLE</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u323" class="ax_default box_1">
                      <div id="u323_div" class=""></div>
                      <div id="u323_text" class="text ">
                        <p><span>The Strokes</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u324" class="ax_default box_1">
                      <div id="u324_div" class=""></div>
                      <div id="u324_text" class="text ">
                        <p><span id="y1">面面</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u325" class="ax_default icon">
                      <img id="u325_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u325_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u326" class="ax_default icon">
                      <img id="u326_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u326_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u327" class="ax_default icon">
                      <img id="u327_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u327_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u328" class="ax_default icon">
                      <img id="u328_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u328_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u329" class="ax_default icon">
                      <img id="u329_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u329_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u330" class="ax_default icon">
                      <img id="u330_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u330_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m305_state1" class="panel_state" data-label="State2" style="visibility: hidden;">
                  <div id="m305_state1_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u331" class="ax_default flow_shape">
                      <div id="u331_div" class=""></div>
                      <div id="u331_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u332" class="ax_default box_1">
                      <img id="u332_div" class="" src="static/resources/images/y21.jpg">
                      <div id="u332_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u333" class="ax_default box_1">
                      <img id="u332_div" class="" src="static/resources/images/y22.jpg">
                      <div id="u332_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u334" class="ax_default box_1">
                      <img id="u332_div" class="" src="static/resources/images/y23.jpg">
                      <div id="u332_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u335" class="ax_default box_1">
                      <img id="u332_div" class="" src="static/resources/images/y24.jpg">
                      <div id="u332_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u336" class="ax_default box_1">
                      <img id="u332_div" class="" src="static/resources/images/y25.jpg">
                      <div id="u332_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u337" class="ax_default box_1">
                      <img id="u332_div" class="" src="static/resources/images/y26.jpg">
                      <div id="u332_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u338" class="ax_default box_1">
                      <img id="u338_img" class="img " src="static/resources/images/page_1/u215.svg"/>
                      <div id="u338_text" class="text ">
                        <p><span>后疫</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u339" class="ax_default box_1">
                      <div id="u339_div" class=""></div>
                      <div id="u339_text" class="text ">
                        <p><span>歌手·当打之年 第8期</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u340" class="ax_default box_1">
                      <div id="u340_div" class=""></div>
                      <div id="u340_text" class="text ">
                        <p><span>我们的乐队 第1期</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u341" class="ax_default box_1">
                      <div id="u341_div" class=""></div>
                      <div id="u341_text" class="text ">
                        <p><span>ZHANG</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u342" class="ax_default box_1">
                      <div id="u342_div" class=""></div>
                      <div id="u342_text" class="text ">
                        <p><span>歌手·当打之年 第9期</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u343" class="ax_default box_1">
                      <img id="u343_img" class="img " src="static/resources/images/page_1/u220.svg"/>
                      <div id="u343_text" class="text ">
                        <p><span>周震南 Vin</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u344" class="ax_default box_1">
                      <div id="u344_div" class=""></div>
                      <div id="u344_text" class="text ">
                        <p><span>窦唯,朝简</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u345" class="ax_default box_1">
                      <div id="u345_div" class=""></div>
                      <div id="u345_text" class="text ">
                        <p><span>周深,徐佳莹,华晨宇</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u346" class="ax_default box_1">
                      <div id="u346_div" class=""></div>
                      <div id="u346_text" class="text ">
                        <p><span>谢霆锋 Nicholas,王...</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u347" class="ax_default box_1">
                      <div id="u347_div" class=""></div>
                      <div id="u347_text" class="text ">
                        <p><span>张钰琪</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u348" class="ax_default box_1">
                      <div id="u348_div" class=""></div>
                      <div id="u348_text" class="text ">
                        <p><span>徐佳莹,吉克隽逸,周深,...</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u349" class="ax_default box_1">
                      <div id="u349_div" class=""></div>
                      <div id="u349_text" class="text ">
                        <p><span>Love&Desire</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u350" class="ax_default icon">
                      <img id="u350_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u350_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u351" class="ax_default icon">
                      <img id="u351_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u351_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u352" class="ax_default icon">
                      <img id="u352_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u352_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u353" class="ax_default icon">
                      <img id="u353_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u353_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u354" class="ax_default icon">
                      <img id="u354_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u354_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u355" class="ax_default icon">
                      <img id="u355_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u355_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m305_state2" class="panel_state" data-label="State3" style="visibility: hidden;">
                  <div id="m305_state2_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u356" class="ax_default flow_shape">
                      <div id="u356_div" class=""></div>
                      <div id="u356_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u357" class="ax_default box_1">
                      <img id="u357_div" class="" src="static/resources/images/y31.jpg">
                      <div id="u357_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u358" class="ax_default box_1">
                      <img id="u357_div" class="" src="static/resources/images/y32.jpg">
                      <div id="u357_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u359" class="ax_default box_1">
                      <img id="u357_div" class="" src="static/resources/images/y33.jpg">
                      <div id="u357_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u360" class="ax_default box_1">
                      <img id="u357_div" class="" src="static/resources/images/y34.jpg">
                      <div id="u357_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u361" class="ax_default box_1">
                      <img id="u357_div" class="" src="static/resources/images/y35.jpg">
                      <div id="u357_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u362" class="ax_default box_1">
                      <img id="u357_div" class="" src="static/resources/images/y36.jpg">
                      <div id="u357_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u363" class="ax_default box_1">
                      <img id="u363_img" class="img " src="static/resources/images/page_1/u215.svg"/>
                      <div id="u363_text" class="text ">
                        <p><span>Song for Our Daughter</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u364" class="ax_default box_1">
                      <div id="u364_div" class=""></div>
                      <div id="u364_text" class="text ">
                        <p><span>Heaven To A Tortured Mind</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u365" class="ax_default box_1">
                      <div id="u365_div" class=""></div>
                      <div id="u365_text" class="text ">
                        <p><span>Rare (Deluxe)</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u366" class="ax_default box_1">
                      <div id="u366_div" class=""></div>
                      <div id="u366_text" class="text ">
                        <p><span>It Is What It Is</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u367" class="ax_default box_1">
                      <div id="u367_div" class=""></div>
                      <div id="u367_text" class="text ">
                        <p><span>Saint Cloud</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u368" class="ax_default box_1">
                      <img id="u368_img" class="img " src="static/resources/images/page_1/u220.svg"/>
                      <div id="u368_text" class="text ">
                        <p><span>Dua Lipa</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u369" class="ax_default box_1">
                      <div id="u369_div" class=""></div>
                      <div id="u369_text" class="text ">
                        <p><span>Laura Marling</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u370" class="ax_default box_1">
                      <div id="u370_div" class=""></div>
                      <div id="u370_text" class="text ">
                        <p><span>Yves Tumor</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u371" class="ax_default box_1">
                      <div id="u371_div" class=""></div>
                      <div id="u371_text" class="text ">
                        <p><span>赛琳娜·戈麦斯 Selena Go...</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u372" class="ax_default box_1">
                      <div id="u372_div" class=""></div>
                      <div id="u372_text" class="text ">
                        <p><span>Thundercat</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u373" class="ax_default box_1">
                      <div id="u373_div" class=""></div>
                      <div id="u373_text" class="text ">
                        <p><span>Waxahatchee</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u374" class="ax_default box_1">
                      <div id="u374_div" class=""></div>
                      <div id="u374_text" class="text ">
                        <p><span>Future Nostalgia</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u375" class="ax_default icon">
                      <img id="u375_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u375_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u376" class="ax_default icon">
                      <img id="u376_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u376_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u377" class="ax_default icon">
                      <img id="u377_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u377_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u378" class="ax_default icon">
                      <img id="u378_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u378_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u379" class="ax_default icon">
                      <img id="u379_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u379_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u380" class="ax_default icon">
                      <img id="u380_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u380_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="m305_state3" class="panel_state" data-label="State4" style="visibility: hidden;">
                  <div id="m305_state3_content" class="panel_state_content">

                    <!-- Unnamed (矩形) -->
                    <div id="u381" class="ax_default flow_shape">
                      <div id="u381_div" class=""></div>
                      <div id="u381_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u382" class="ax_default box_1">
                      <img id="u382_div" class="" src="static/resources/images/y51.jpg">
                      <div id="u382_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u383" class="ax_default box_1">
                      <img id="u382_div" class="" src="static/resources/images/y52.jpg">
                      <div id="u382_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u384" class="ax_default box_1">
                      <img id="u382_div" class="" src="static/resources/images/y53.jpg">
                      <div id="u382_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u385" class="ax_default box_1">
                      <img id="u382_div" class="" src="static/resources/images/y54.jpg">
                      <div id="u382_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u386" class="ax_default box_1">
                      <img id="u382_div" class="" src="static/resources/images/y55.jpg">
                      <div id="u382_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u387" class="ax_default box_1">
                      <img id="u382_div" class="" src="static/resources/images/y56.jpg">
                      <div id="u382_text" class="text ">
                        <p><span></span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u388" class="ax_default box_1">
                      <img id="u388_img" class="img " src="static/resources/images/page_1/u215.svg"/>
                      <div id="u388_text" class="text ">
                        <p><span>LOOK</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u389" class="ax_default box_1">
                      <div id="u389_div" class=""></div>
                      <div id="u389_text" class="text ">
                        <p><span>ニュース</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u390" class="ax_default box_1">
                      <div id="u390_div" class=""></div>
                      <div id="u390_text" class="text ">
                        <p><span>4집 PEOPLE</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u391" class="ax_default box_1">
                      <div id="u391_div" class=""></div>
                      <div id="u391_text" class="text ">
                        <p><span>IT'z ME</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u392" class="ax_default box_1">
                      <div id="u392_div" class=""></div>
                      <div id="u392_text" class="text ">
                        <p><span>자화상 (Self-Portrait)</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u393" class="ax_default box_1">
                      <img id="u393_img" class="img " src="static/resources/images/page_1/u220.svg"/>
                      <div id="u393_text" class="text ">
                        <p><span>위너,WINNER</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u394" class="ax_default box_1">
                      <div id="u394_div" class=""></div>
                      <div id="u394_text" class="text ">
                        <p><span>에이핑크,Apink</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u395" class="ax_default box_1">
                      <div id="u395_div" class=""></div>
                      <div id="u395_text" class="text ">
                        <p><span>东京事变 Tokyo Incide...</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u396" class="ax_default box_1">
                      <div id="u396_div" class=""></div>
                      <div id="u396_text" class="text ">
                        <p><span>코드 쿤스트,赵成佑...</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u397" class="ax_default box_1">
                      <div id="u397_div" class=""></div>
                      <div id="u397_text" class="text ">
                        <p><span>있지,ITZY</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u398" class="ax_default box_1">
                      <div id="u398_div" class=""></div>
                      <div id="u398_text" class="text ">
                        <p><span>수호,SUHO</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (矩形) -->
                    <div id="u399" class="ax_default box_1">
                      <div id="u399_div" class=""></div>
                      <div id="u399_text" class="text ">
                        <p><span>3집 Remember</span></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u400" class="ax_default icon">
                      <img id="u400_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u400_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u401" class="ax_default icon">
                      <img id="u401_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u401_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u402" class="ax_default icon">
                      <img id="u402_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u402_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u403" class="ax_default icon">
                      <img id="u403_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u403_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u404" class="ax_default icon">
                      <img id="u404_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u404_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>

                    <!-- Unnamed (形状) -->
                    <div id="u405" class="ax_default icon">
                      <img id="u405_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                      <div id="u405_text" class="text " style="display:none; visibility: hidden">
                        <p></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div id="test1">
                <div id="u406" class="ax_default image">
                  <img id="u406_img"  class="img roll_image" style="left: 0px" src="static/resources/images/page_1/69.jpg"/>
                  <img id="u69_img1"  class="img roll_image" style="left:1020px" src="static/resources/images/page_1/70.jpg"/>
                  <img id="u69_img2"  class="img roll_image" style="left:2040px" src="static/resources/images/page_1/71.jpg"/>
                  <img id="u69_img3"  class="img roll_image" style="left:-1020px" src="static/resources/images/page_1/72.jpg"/>
                  <div id="u69_text" class="text " style="display:none; visibility: hidden">
                    <p></p>
                  </div>
                </div>

                <!-- Unnamed (矩形) -->
                <button id="u407" class="ax_default box_1" @click="test">
                  <div id="u407_div" class=""  ></div>
                  <div id="u407_text" class="text " style="display:none; visibility: hidden" >
                    <p></p>
                  </div>
                </button>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u408" class="ax_default ellipse">
                <img id="u408_img" class="img buttom_image" src="static/resources/images/page_1/u408.svg"/>
                <div id="u408_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u409" class="ax_default ellipse">
                <img id="u409_img" class="img buttom_image" src="static/resources/images/page_1/u409.svg"/>
                <div id="u409_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u410" class="ax_default ellipse">
                <img id="u410_img" class="img buttom_image" src="static/resources/images/page_1/u409.svg"/>
                <div id="u410_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u411" class="ax_default ellipse">
                <img id="u411_img" class="img buttom_image" src="static/resources/images/page_1/u409.svg"/>
                <div id="u411_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u412" class="ax_default line">
                <img id="u412_img" class="img " src="static/resources/images/page_1/u412.svg"/>
                <div id="u412_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u413" class="ax_default line">
                <img id="u413_img" class="img " src="static/resources/images/page_1/u412.svg"/>
                <div id="u413_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u414" class="ax_default box_1">
                <div id="u414_div" class=""></div>
                <div id="u414_text" class="text ">
                  <p><span>本周流行音乐</span></p>
                </div>
              </div>

              <!-- ly1 (矩形) -->
              <div id="dy415" class="ax_default box_1 selected" data-label="ly1" selectiongroup="3" style="cursor:pointer;color:black">
                <div id="u415_div" class="selected"></div>
                <div id="u415_text" class="text ">
                  <p><span>最热</span></p>
                </div>
              </div>

              <!-- ly2 (矩形) -->
              <div id="dy416" class="ax_default box_1" data-label="ly2" selectiongroup="3" style="cursor:pointer">
                <div id="u416_div" class=""></div>
                <div id="u416_text" class="text ">
                  <p><span>华语</span></p>
                </div>
              </div>

              <!-- ly3 (矩形) -->
              <div id="dy417" class="ax_default box_1" data-label="ly3" selectiongroup="3" style="cursor:pointer">
                <div id="u417_div" class=""></div>
                <div id="u417_text" class="text ">
                  <p><span>欧美</span></p>
                </div>
              </div>

              <!-- ly4 (矩形) -->
              <div id="dy418" class="ax_default box_1" data-label="ly4" selectiongroup="3" style="cursor:pointer">
                <div id="u418_div" class=""></div>
                <div id="u418_text" class="text ">
                  <p><span>日韩</span></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u419" class="ax_default line">
                <img id="u419_img" class="img " src="static/resources/images/page_1/u419.svg"/>
                <div id="u419_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u420" class="ax_default box_1">
                <div id="u420_div" class=""></div>
                <div id="u420_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u421" class="ax_default line">
                <img id="u421_img" class="img " src="static/resources/images/page_1/u421.svg"/>
                <div id="u421_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u422" class="ax_default box_1">
                <div id="u422_div" class=""></div>
                <div id="u422_text" class="text ">
                  <p style="font-size:13px;"><span style="font-family:'Arial Normal', 'Arial', sans-serif;"><br></span></p><p style="font-size:18px;"><span style="font-family:'Comic Sans MS Normal', 'Comic Sans MS', sans-serif;">歌曲数</span></p><p style="font-size:18px;"><span style="font-family:'Comic Sans MS Normal', 'Comic Sans MS', sans-serif;">3066</span></p><p style="font-size:13px;"><span style="font-family:'Arial Normal', 'Arial', sans-serif;"><br></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u423" class="ax_default box_1">
                <div id="u423_div" class=""></div>
                <div id="u423_text" class="text ">
                  <p><span>热门音乐人</span></p>
                </div>
              </div>


              <!-- Unnamed (线段) -->
              <div id="u428" class="ax_default line">
                <img id="u428_img" class="img " src="static/resources/images/page_1/u419.svg"/>
                <div id="u428_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u429" class="ax_default box_1">
                <div id="u429_div" class=""></div>
                <div id="u429_text" class="text ">
                  <p><span>单曲榜</span></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u430" class="ax_default line">
                <img id="u430_img" class="img " src="static/resources/images/page_1/u430.svg"/>
                <div id="u430_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u431" class="ax_default icon">
                <img id="u431_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                <div id="u431_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u432" class="ax_default icon">
                <img id="u432_img" class="img " src="static/resources/images/page_1/u227.svg"/>
                <div id="u432_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u433" class="ax_default image">
                <img id="u433_img" class="img " src="static/resources/images/page_1/u433.png"/>
                <div id="u433_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u434" class="ax_default image">
                <img id="u434_img" class="img " src="static/resources/images/page_1/u434.png"/>
                <div id="u434_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u435" class="ax_default image">
                <img id="u435_img" class="img " src="static/resources/images/page_1/u435.png"/>
                <div id="u435_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u436" class="ax_default ellipse">
                <img id="u436_img" class="img " src="static/resources/images/y5.jpg" />
                <div id="u436_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u437" class="ax_default ellipse">
                <img id="u436_img" class="img " src="static/resources/images/y21.jpg" />
                <div id="u437_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u438" class="ax_default ellipse">
                <img id="u436_img" class="img " src="static/resources/images/y34.jpg" />
                <div id="u438_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u439" class="ax_default box_1">
                <div id="u439_div" class=""></div>
                <div id="u439_text" class="text ">
                  <p style="font-size:13px;"><span><br></span></p><p style="font-size:17px;"><span style="color:#71B5D2;">新世界</span></p><p style="font-size:13px;"><span style="color:#797979;"></span>华晨宇</p><p style="font-size:13px;"><span><br></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u440" class="ax_default box_1">
                <div id="u440_div" class=""></div>
                <div id="u440_text" class="text ">
                  <p style="font-size:13px;"><span><br></span></p><p style="font-size:17px;"><span style="color:#71B5D2;">Love&Desire</span></p><p style="font-size:13px;"><span style="color:#797979;">周震南 Vin</span></p><p style="font-size:13px;"><span><br></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u441" class="ax_default box_1">
                <div id="u441_div" class=""></div>
                <div id="u441_text" class="text ">
                  <p style="font-size:13px;"><span><br></span></p><p style="font-size:17px;"><span style="color:#71B5D2;">Rare (Deluxe)</span></p><p style="font-size:13px;"><span style="color:#797979;">Selena Gomez</span></p><p style="font-size:13px;"><span><br></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u442" class="ax_default box_1">
                <div id="u442_div" class=""></div>
                <div id="u442_text" class="text ">
                  <p><span>关注我们</span></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u443" class="ax_default line">
                <img id="u443_img" class="img " src="static/resources/images/page_1/u197.svg"/>
                <div id="u443_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u444" class="ax_default image">
                <img id="u444_img" class="img " src="static/resources/images/page_1/u204.png"/>
                <div id="u444_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u445" class="ax_default image">
                <img id="u445_img" class="img " src="static/resources/images/page_1/u205.png"/>
                <div id="u445_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>
            </div>
          </div>
          <div id="state2" class="panel_state"  >
            <div id="u0_state2_content" class="panel_state_content">

              <!-- Unnamed (矩形) -->
              <div id="u446" class="ax_default box_1">
                <div id="u446_div" class=""></div>
                <div id="u446_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u447" class="ax_default image">
                <img id="u447_img" class="img " src="static/resources/images/page_1/u447.png"/>
                <div id="u447_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u448" class="ax_default box_1">
                <div id="u448_div" class=""></div>
                <div id="u448_text" class="text ">
                  <p><span>精选读物</span></p>
                </div>
              </div>

              <!-- Unnamed (线段) -->
              <div id="u449" class="ax_default line">
                <img id="u449_img" class="img " src="static/resources/images/page_1/u449.svg"/>
                <div id="u449_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u450" class="ax_default box_1">
                <img id="u450_div" class="" src="static/resources/images/h6.jpg">
                <div id="u450_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u451" class="ax_default box_1">
                <img id="u451_div" class="" src="static/resources/images/h2.jpg">
                <div id="u450_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u452" class="ax_default box_1">
                <img id="u452_div" class="" src="static/resources/images/h3.jpg">
                <div id="u450_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u453" class="ax_default box_1">
                <img id="u453_div" class="" src="static/resources/images/h4.jpg">
                <div id="u450_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u454" class="ax_default box_1">
                <img id="u454_div" class="" src="static/resources/images/h5.jpg">
                <div id="u450_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u455" class="ax_default box_1">
                <img id="u455_div" class="" src="static/resources/images/h1.jpg">
                <div id="u450_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u456" class="ax_default box_1">
                <img id="u456_div" class="" src="static/resources/images/h7.jpg">
                <div id="u450_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u457" class="ax_default box_1">
                <img id="u457_div" class="" src="static/resources/images/h8.jpg">
                <div id="u450_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u458" class="ax_default box_1">
                <div id="u458_div" class=""></div>
                <div id="u458_text" class="text ">
                  <p><span id="d1">伦敦人</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u459" class="ax_default box_1">
                <div id="u459_div" class=""></div>
                <div id="u459_text" class="text ">
                  <p><span id="d2">护士的故事</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u460" class="ax_default box_1">
                <div id="u460_div" class=""></div>
                <div id="u460_text" class="text ">
                  <p><span id="d3">J</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u461" class="ax_default box_1">
                <div id="u461_div" class=""></div>
                <div id="u461_text" class="text ">
                  <p><span id="d4">苏世民:我的经验和教训</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u462" class="ax_default box_1">
                <div id="u462_div" class=""></div>
                <div id="u462_text" class="text ">
                  <p><span id="d5">柏林苍穹下</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u463" class="ax_default box_1">
                <div id="u463_div" class=""></div>
                <div id="u463_text" class="text ">
                  <p><span id="d6">伦敦人</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u464" class="ax_default box_1">
                <div id="u464_div" class=""></div>
                <div id="u464_text" class="text ">
                  <p><span id="d7">万有引力之虹</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u465" class="ax_default box_1">
                <div id="u465_div" class=""></div>
                <div id="u465_text" class="text ">
                  <p><span id="d8">想见你</span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u466" class="ax_default box_1">
                <div id="u466_div" class=""></div>
                <div id="u466_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u467" class="ax_default box_1">
                <div id="u467_div" class=""></div>
                <div id="u467_text" class="text ">
                  <p><span>热门标签</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u468" class="ax_default icon">
                <img id="u468_img" class="img " src="static/resources/images/page_1/u468.svg"/>
                <div id="u468_text" class="text ">
                  <p><span>梦想</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u469" class="ax_default icon">
                <img id="u469_img" class="img " src="static/resources/images/page_1/u468.svg"/>
                <div id="u469_text" class="text ">
                  <p><span>治愈</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u470" class="ax_default icon">
                <img id="u470_img" class="img " src="static/resources/images/page_1/u470.svg"/>
                <div id="u470_text" class="text ">
                  <p><span>爱情</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u471" class="ax_default icon">
                <img id="u471_img" class="img " src="static/resources/images/page_1/u468.svg"/>
                <div id="u471_text" class="text ">
                  <p><span>励志</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u472" class="ax_default icon">
                <img id="u472_img" class="img " src="static/resources/images/page_1/u468.svg"/>
                <div id="u472_text" class="text ">
                  <p><span>随笔</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u473" class="ax_default icon">
                <img id="u473_img" class="img " src="static/resources/images/page_1/u473.svg"/>
                <div id="u473_text" class="text ">
                  <p><span>随笔</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u474" class="ax_default icon">
                <img id="u474_img" class="img " src="static/resources/images/page_1/u474.svg"/>
                <div id="u474_text" class="text ">
                  <p><span>随笔</span></p>
                </div>
              </div>

              <!-- Unnamed (形状) -->
              <div id="u475" class="ax_default icon">
                <img id="u475_img" class="img " src="static/resources/images/page_1/u475.svg"/>
                <div id="u475_text" class="text ">
                  <p><span>随笔</span></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <div id="u476" class="ax_default image">
                <img id="u476_img" class="img " src="static/resources/images/page_1/u476.jpg"/>
                <div id="u476_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->
              <div id="u477" class="ax_default box_1">
                <div id="u477_div" class=""></div>
                <div id="u477_text" class="text ">
                  <p><span>新书速递</span></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u478" class="ax_default ellipse ">
                <img id="u478_img" class="img roll_content" src="static/resources/images/page_1/u478.svg"/>
                <div id="u478_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u479" class="ax_default ellipse ">
                <img id="u479_img" class="img roll_content" src="static/resources/images/page_1/u409.svg"/>
                <div id="u479_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u480" class="ax_default ellipse">
                <img id="u480_img" class="img roll_content" src="static/resources/images/page_1/u409.svg"/>
                <div id="u480_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (圆形) -->
              <div id="u481" class="ax_default ellipse ">
                <img id="u481_img" class="img roll_content" src="static/resources/images/page_1/u409.svg "/>
                <div id="u481_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>

              <!-- Unnamed (图片 ) -->
              <button id="u482" class="ax_default image " >
                <img id="u482_img" class="img " src="static/resources/images/page_1/u482.png"/>
                <div id="u482_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </button>

              <!-- Unnamed (图片 ) -->


              <!-- Unnamed (矩形) -->
              <div id="u484" class="ax_default box_1">
                <div id="u484_div" class=""></div>
                <div id="u484_text" class="text " style="display:none; visibility: hidden">
                  <p></p>
                </div>
              </div>




              <div>
                <div id="o1" class="ax_default outside" style="margin-left:56px; left:0px" >
                  <div id="u485" class="">
                    <img id="u485_div" class="" src="static/resources/images/1.jpg">
                    <div id="u485_text" class="text ">
                      <p><span></span></p>
                    </div>

                  </div>

                  <!-- Unnamed (矩形) -->
                  <div id="u486" class="ax_default box_1">
                    <div id="u486_div" class=""></div>
                    <div id="u486_text" class="text ">
                      <p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span>在森林里住着一群野猫，由四个族群组成：雷族、风族、影族、河族。他们继承祖先（死去的猫，住在天上，是星族猫）留下来的武士传统，为了生存而彼此竞争。猫武士系列长篇小说就是描写族群猫的生活场景，故事随着一些有着特殊命运的猫展开，情节曲折复杂，引人入胜。</span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p>
                    </div>
                  </div>
                </div>

                <div id="o2" class="ax_default outside" style="margin-left:56px;left:1000px">
                  <div id="u485" class="">
                    <img id="u485_div" class="" src="static/resources/images/2.jpg">
                    <div id="u485_text" class="text ">
                      <p><span></span></p>
                    </div>

                  </div>

                  <!-- Unnamed (矩形) -->
                  <div id="u486" class="ax_default box_1">
                    <div id="u486_div" class=""></div>
                    <div id="u486_text" class="text ">
                      <p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span>
                    《我的同时代人的故事》是柯罗连科的长篇自传小说。书中叙述了他的童年时代、中学生时代、专科学生时代、维亚特边区流放时代、雅库茨克省流放时代的生活，即从19世纪50年代中叶到80年代中叶的情况。</span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p>
                    </div>
                  </div>
                </div>

                <div id="o3" class="ax_default outside" style="margin-left:56px;left:2000px">
                  <div id="u485" class="">
                    <img id="u485_div" class="" src="static/resources/images/3.jpg">
                    <div id="u485_text" class="text ">
                      <p><span></span></p>
                    </div>

                  </div>

                  <!-- Unnamed (矩形) -->
                  <div id="u486" class="ax_default box_1">
                    <div id="u486_div" class=""></div>
                    <div id="u486_text" class="text ">
                      <p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span>
                    《阅读的故事》是专业读书人唐诺谈阅读的经典散文作品，一部诚恳实用的阅读辞海。以马尔克斯《迷宫中的将军》的片段开启每一章的话题，探讨书籍和阅读的本质困境与种种迷思。</span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p>
                    </div>
                  </div>
                </div>

                <div id="o4" class="ax_default outside" style="margin-left:56px;left:-1000px">
                  <div id="u485" class="">
                    <img id="u485_div" class="" src="static/resources/images/4.jpg">
                    <div id="u485_text" class="text ">
                      <p><span></span></p>
                    </div>

                  </div>

                  <!-- Unnamed (矩形) -->
                  <div id="u486" class="ax_default box_1">
                    <div id="u486_div" class=""></div>
                    <div id="u486_text" class="text ">
                      <p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span><br></span></p><p style="font-size:19px;"><span>
                    这是一个既献给伟大音乐家，也献给一颗伟大心灵的故事。<br>
                  贝多芬的一生难称幸福。世人向往的爱情和圆满家庭与他无缘，病痛与磨难始终徘徊不散，健康的体魄也变成奢求，他要借助纸条才能与他人交流。但他从未丧失对生活的热情，始终渴望成为一个善良、高贵，并为人类献身的人。</span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p><p style="font-size:13px;"><span><br></span></p>
                    </div>
                  </div>
                </div>
              </div>



              <!-- Unnamed (矩形) -->


              <!-- Unnamed (矩形) -->
              <div id="u487" class="ax_default box_1">
                <div id="u487_div" class=""></div>
                <div id="u487_text" class="text ">
                  <p><span></span></p>
                </div>
              </div>

              <!-- Unnamed (矩形) -->

            </div>

          </div>

          <!-- Unnamed (矩形) -->
          <div id="u489" class="ax_default box_1">
            <img id="u489_img" class="img " src="static/resources/images/page_1/u489.svg"/>
            <div id="u489_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>

          <!-- Unnamed (矩形) -->
          <div id="u490" class="ax_default box_1">
            <img id="u490_img" class="img " src="static/resources/images/page_1/u490.svg"/>
            <div id="u490_text" class="text ">
              <p><span>豌豆射手</span></p>
            </div>
          </div>

          <!-- Unnamed (矩形) -->


          <!-- Unnamed (图片 ) -->


          <!-- Unnamed (文本框) -->


          <!-- Unnamed (图片 ) -->
          <div id="u494" class="ax_default image">
            <img id="u494_img" class="img " src="static/resources/images/page_1/u494.png"/>
            <div id="u494_text" class="text " style="display:none; visibility: hidden">
              <p></p>
            </div>
          </div>
          <button id="new1">
            <p ><span>电影</span></p>
          </button>
          <!-- Unnamed (矩形) -->


          <!-- Unnamed (矩形) -->
          <button id="new2" >
            <p><span>音乐</span></p>
          </button>

          <!-- Unnamed (矩形) -->
          <button id="new3" >
            <p><span >读书</span></p>
          </button>
          <div id="state3" class="panel_state">
            <button id="detail_button" class="btn btn-info" btn-lg>返回广场</button>
            <br>
            <img id="detail_img" src="static/resources/images/page_1/u494.png"/>
            <div>标题</div>
            <div>简介:</div>
            <div>标签</div>
          </div>


        </div>

      </div>




    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>



    <div style="top:1000px">
      <myfoot></myfoot>
    </div>

  </div>
</template>


<script>
  import myfoot from "../myfoot";
  import myhead from "../myhead";
  /*import Myfoot from "../myfoot";*/
  var inter1;
  var inter2;
  export default {
    name: 'hello',
    components: {
      myhead,
      myfoot
    },
    methods:{
      test()
      {

      },
      goto()
      {

      },

      click_status()
      {
        var dy176=document.getElementById("dy176");
        var dy177=document.getElementById("dy177");
        var dy178=document.getElementById("dy178");
        var dy179=document.getElementById("dy179");
        var dy180=document.getElementById("dy180");
        var state1=document.getElementById("m82_state0");
        var state2=document.getElementById("m82_state1");
        var state3=document.getElementById("m82_state2");
        var state4=document.getElementById("m82_state3");
        var state5=document.getElementById("m82_state4");
        dy176.onclick=function()
        {
          dy176.style.color="black";
          dy177.style.color="#D4CACA";
          dy178.style.color="#D4CACA";
          dy179.style.color="#D4CACA";
          dy180.style.color="#D4CACA";
          state1.style.visibility="visible";
          state2.style.visibility="hidden";
          state3.style.visibility="hidden";
          state4.style.visibility="hidden";
          state5.style.visibility="hidden";
        }
        dy177.onclick=function()
        {
          dy176.style.color="#D4CACA";
          dy177.style.color="black";
          dy178.style.color="#D4CACA";
          dy179.style.color="#D4CACA";
          dy180.style.color="#D4CACA";
          state1.style.visibility="hidden";
          state2.style.visibility="visible";
          state3.style.visibility="hidden";
          state4.style.visibility="hidden";
          state5.style.visibility="hidden";
        }

        dy178.onclick=function()
        {
          dy176.style.color="#D4CACA";
          dy177.style.color="#D4CACA";
          dy178.style.color="black";
          dy179.style.color="#D4CACA";
          dy180.style.color="#D4CACA";
          state1.style.visibility="hidden";
          state2.style.visibility="hidden";
          state3.style.visibility="visible";
          state4.style.visibility="hidden";
          state5.style.visibility="hidden";
        }

        dy179.onclick=function()
        {
          dy176.style.color="#D4CACA";
          dy177.style.color="#D4CACA";
          dy178.style.color="#D4CACA";
          dy179.style.color="black";
          dy180.style.color="#D4CACA";
          state1.style.visibility="hidden";
          state2.style.visibility="hidden";
          state3.style.visibility="hidden";
          state4.style.visibility="visible";
          state5.style.visibility="hidden";
        }

        dy180.onclick=function()
        {
          dy176.style.color="#D4CACA";
          dy177.style.color="#D4CACA";
          dy178.style.color="#D4CACA";
          dy179.style.color="#D4CACA";
          dy180.style.color="black";
          state1.style.visibility="hidden";
          state2.style.visibility="hidden";
          state3.style.visibility="hidden";
          state4.style.visibility="hidden";
          state5.style.visibility="visible";
        }
        var dy190=document.getElementById("dy190");
        var dy191=document.getElementById("dy191");
        var dy192=document.getElementById("dy192");
        var dy193=document.getElementById("dy193");
        var state11=document.getElementById("m1_state0");
        var state22=document.getElementById("m1_state1");
        var state33=document.getElementById("m1_state2");
        var state44=document.getElementById("m1_state3");
        dy190.onclick=function()
        {
          dy190.style.color="black";
          dy191.style.color="#D4CACA";
          dy192.style.color="#D4CACA";
          dy193.style.color="#D4CACA";

          state11.style.visibility="visible";
          state22.style.visibility="hidden";
          state33.style.visibility="hidden";
          state44.style.visibility="hidden";

        }
        dy191.onclick=function()
        {
          dy190.style.color="#D4CACA";
          dy191.style.color="black";
          dy192.style.color="#D4CACA";
          dy193.style.color="#D4CACA";

          state11.style.visibility="hidden";
          state22.style.visibility="visible";
          state33.style.visibility="hidden";
          state44.style.visibility="hidden";


        }

        dy192.onclick=function()
        {
          dy190.style.color="#D4CACA";
          dy191.style.color="#D4CACA";
          dy192.style.color="black";
          dy193.style.color="#D4CACA";

          state11.style.visibility="hidden";
          state22.style.visibility="hidden";
          state33.style.visibility="visible";
          state44.style.visibility="hidden";


        }

        dy193.onclick=function()
        {
          dy190.style.color="#D4CACA";
          dy191.style.color="#D4CACA";
          dy192.style.color="#D4CACA";
          dy193.style.color="black";

          state11.style.visibility="hidden";
          state22.style.visibility="hidden";
          state33.style.visibility="hidden";
          state44.style.visibility="visible";


        }

        var dy1901=document.getElementById("dy415");
        var dy1911=document.getElementById("dy416");
        var dy1921=document.getElementById("dy417");
        var dy1931=document.getElementById("dy418");
        var state111=document.getElementById("m305_state0");
        var state221=document.getElementById("m305_state1");
        var state331=document.getElementById("m305_state2");
        var state441=document.getElementById("m305_state3");
        dy1901.onclick=function()
        {
          dy1901.style.color="black";
          dy1911.style.color="#D4CACA";
          dy1921.style.color="#D4CACA";
          dy1931.style.color="#D4CACA";

          state111.style.visibility="visible";
          state221.style.visibility="hidden";
          state331.style.visibility="hidden";
          state441.style.visibility="hidden";

        }
        dy1911.onclick=function()
        {
          dy1901.style.color="#D4CACA";
          dy1911.style.color="black";
          dy1921.style.color="#D4CACA";
          dy1931.style.color="#D4CACA";

          state111.style.visibility="hidden";
          state221.style.visibility="visible";
          state331.style.visibility="hidden";
          state441.style.visibility="hidden";


        }

        dy1921.onclick=function()
        {
          dy1901.style.color="#D4CACA";
          dy1911.style.color="#D4CACA";
          dy1921.style.color="black";
          dy1931.style.color="#D4CACA";

          state111.style.visibility="hidden";
          state221.style.visibility="hidden";
          state331.style.visibility="visible";
          state441.style.visibility="hidden";


        }

        dy1931.onclick=function()
        {
          dy1901.style.color="#D4CACA";
          dy1911.style.color="#D4CACA";
          dy1921.style.color="#D4CACA";
          dy1931.style.color="black";

          state111.style.visibility="hidden";
          state221.style.visibility="hidden";
          state331.style.visibility="hidden";
          state441.style.visibility="visible";
        }
      },
      move_picture()
      {

        //var imgs=["images/page_1/69.jpg","images/page_1/70.jpg","images/page_1/71.jpg","images/page_1/72.jpg"];
        var oIpt=document.getElementById("u482");
        var allColor1=document.getElementsByClassName("outside");
        var all_buttom1=document.getElementsByClassName("roll_content");
        oIpt.onclick=function()
        {
          for(var m=0;m< 4;m++){
            if(all_buttom1[m].getAttribute("src")=="static/resources/images/page_1/u478.svg")
            {
              all_buttom1[(m+1)%4].setAttribute("src","static/resources/images/page_1/u478.svg");
              all_buttom1[m].setAttribute("src","static/resources/images/page_1/u409.svg");
              break;
            }
          }
          for(var m=0;m<4;m++){
            allColor1[m].style.left=parseFloat(allColor1[m].style.left)-1000+"px";
            allColor1[m].style.transition=1+"s";
            if(allColor1[m].style.left==-3000+"px"){
              allColor1[m].style.left=1000+"px";
              allColor1[m].style.transition=0+"s";
            }
          }
        }
        inter1=setInterval(oIpt.onclick,3000);

        var oIpt2=document.getElementById("u407");
        var allColor=document.getElementsByClassName("roll_image");
        var all_buttom=document.getElementsByClassName("buttom_image");
        oIpt2.onclick=function()
        {
          for(var i=0;i< 4;i++){
            if(all_buttom[i].getAttribute("src")=="static/resources/images/page_1/u408.svg")
            {
              all_buttom[(i+1)%4].setAttribute("src","static/resources/images/page_1/u408.svg");
              all_buttom[i].setAttribute("src","static/resources/images/page_1/u409.svg");
              break;
            }
          }
          for(var i=0;i<allColor.length;i++){
            allColor[i].style.left=parseFloat(allColor[i].style.left)-1020+"px";
            allColor[i].style.transition=1+"s";
            if(allColor[i].style.left==-3060+"px"){
              allColor[i].style.left=1020+"px";
              allColor[i].style.transition=0+"s";
            }
          }
        }
        inter2=setInterval(oIpt2.onclick,3000);
      },
      cevent()
      {
        var j1=document.getElementById("new1");
        var j2=document.getElementById("new2");
        var j3=document.getElementById("new3");
        j1.onclick=function()
        {

          //document.getElementById("u83_div").setAttribute("value","2");
          //console.log($(document.getElementById("u83_div")).attr("value"));
          document.getElementById("state0").style.visibility="visible";
          document.getElementById("state0").style.display="inline";
          document.getElementById("state1").style.visibility="hidden";
          document.getElementById("state1").style.display="none";
          document.getElementById("state2").style.visibility="hidden";
          document.getElementById("state2").style.display="none";
          document.getElementById("state3").style.visibility="hidden";
          document.getElementById("state3").style.display="none";
        }
        j2.onclick=function()
        {
          document.getElementById("state0").style.visibility="hidden";
          document.getElementById("state0").style.display="none";
          document.getElementById("state1").style.visibility="visible";
          document.getElementById("state1").style.display="inline";
          document.getElementById("state2").style.visibility="hidden";
          document.getElementById("state2").style.display="none";
          document.getElementById("state3").style.visibility="hidden";
          document.getElementById("state3").style.display="none";
        }
        j3.onclick=function()
        {
          document.getElementById("state0").style.visibility="hidden";
          document.getElementById("state0").style.display="none";
          document.getElementById("state1").style.visibility="hidden";
          document.getElementById("state1").style.display="none";
          document.getElementById("state2").style.visibility="visible";
          document.getElementById("state2").style.display="inline";
          document.getElementById("state3").style.visibility="hidden";
          document.getElementById("state3").style.display="none";
        }
      },

    },

    mounted:function(){
      this.cevent();
      this.goto();
      this.move_picture();
      this.click_status();
    },
    created:function(){

      var qs = require('qs');
      //电影读取
      this.$axios({
        method: 'post',
        url: '/api/shares/getbytags',
        data:qs.stringify({
          tags:"电影",
          type:"hot"
        }),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
      }).then(function (res) {
        console.log(res);
        const dres=res.data;
        var m,n;
        var temp_data;
        var flag=0;

        var s1="u";
        var s2="_div";
        var s3=83;
        var s4=91;
        var s5=91;
        var i;
        var sa1="a";
        var sa2=1;



        for(i=0;i<8;i++)
        {

          var idstring=s1+s3+s2;
          var namestring=sa1+sa2;
          var dydiv=document.getElementById(idstring);
          var naspan=document.getElementById(namestring);
          dydiv.src="http://129.204.247.165/"+dres.data[i].route;
          naspan.innerHTML=dres.data[i].title
          if(dres.data[i].title.length>8)
            naspan.innerHTML=naspan.innerHTML.substring(0,8)+"...";
          s3=s3+1;
          sa2++;
        }



      }).catch(function (res) {
        console.log(res)
      })
      //电视剧读取
      this.$axios({
        method: 'post',
        url: '/api/shares/getbytags',
        data:qs.stringify({
          tags:"电视剧",
        }),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
      }).then(function (res) {
        console.log(res);
        const dres=res.data;
        var m,n;
        var temp_data;
        var flag=0;
        for(m=0;m<dres.data.length;m++)
        {
          flag=0
          for(n=0;n<dres.data.length-1;n++)
          {
            if(dres.data[n].times<dres.data[n+1].times)
            {
              dres.temp_data=dres.data[n];
              dres.data[n]=dres.data[n+1];
              dres.data[n+1]=dres.temp_data;
              flag=1;
            }
          }
          if(flag==0)
            break;
        }
        var s1="u";
        var s2="_div";
        var s3=2;
        var i;
        var sa1="a";
        var sa2=9;



        for(i=0;i<8;i++)
        {

          var idstring=s1+s3+s2;
          var namestring=sa1+sa2;
          console.log(namestring);
          var dydiv=document.getElementById(idstring);
          var naspan=document.getElementById(namestring);
          dydiv.src="http://129.204.247.165/"+dres.data[i].route;
          naspan.innerHTML=dres.data[i].title;
          if(dres.data[i].title.length>8)
            naspan.innerHTML=naspan.innerHTML.substring(0,8)+"...";
          s3=s3+1;
          sa2++;
        }



      }).catch(function (res) {
        console.log(res)
      })
      //读取音乐
      this.$axios({
        method: 'post',
        url: '/api/shares/getbytags',
        data:qs.stringify({
          tags:"音乐",
        }),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
      }).then(function (res) {
        console.log(res);
        const dres=res.data;
        var m,n;
        var temp_data;
        var flag=0;
        for(m=0;m<dres.data.length;m++)
        {
          flag=0
          for(n=0;n<dres.data.length-1;n++)
          {
            if(dres.data[n].times<dres.data[n+1].times)
            {
              dres.temp_data=dres.data[n];
              dres.data[n]=dres.data[n+1];
              dres.data[n+1]=dres.temp_data;
              flag=1;
            }
          }
          if(flag==0)
            break;
        }
        var s1="u";
        var s2="_div";
        var s3=307;
        var i;
        var sa1="y";
        var sa2=1;



        for(i=0;i<6;i++)
        {

          var idstring=s1+s3+s2;
          var namestring=sa1+sa2;
          var dydiv=document.getElementById(idstring);
          var naspan=document.getElementById(namestring);
          dydiv.src="http://129.204.247.165/"+dres.data[i].route;
          naspan.innerHTML=dres.data[i].title;
          if(dres.data[i].title.length>8)
            naspan.innerHTML=naspan.innerHTML.substring(0,8)+"...";

          s3=s3+1;
          sa2++;
        }



      }).catch(function (res) {
        console.log(res)
      })
      this.$axios({
        method: 'post',
        url: '/api/shares/getbytags',
        data:qs.stringify({
          tags:"电影",
          type:"time"
        }),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'

        },
      }).then(function (res) {
        console.log(res);
        const dres=res.data;
        var m,n;
        var temp_data;
        var flag=0;

        var s1="u";
        var s2="_div";
        var s3=101;
        var s4=91;
        var s5=91;
        var i;
        var sa1="a";
        var sa2=17;



        for(i=0;i<8;i++)
        {

          var idstring=s1+s3+s2;
          var namestring=sa1+sa2;
          var dydiv=document.getElementById(idstring);
          var naspan=document.getElementById(namestring);
          dydiv.src="http://129.204.247.165/"+dres.data[i].route;
          naspan.innerHTML=dres.data[i].title;
          if(dres.data[i].title.length>8)
            naspan.innerHTML=naspan.innerHTML.substring(0,8)+"...";
          s3=s3+1;
          sa2++;
        }



      }).catch(function (res) {
        console.log(res)
      })
      this.$axios({
        method: 'post',
        url: '/api/shares/getbytags',
        data:qs.stringify({
          tags:"读书",
          type:"hot",
        }),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
      }).then(function (res) {
        console.log(res);
        const dres=res.data;
        var m,n;
        var temp_data;
        var flag=0;
        for(m=0;m<dres.data.length;m++)
        {
          flag=0
          for(n=0;n<dres.data.length-1;n++)
          {
            if(dres.data[n].times<dres.data[n+1].times)
            {
              dres.temp_data=dres.data[n];
              dres.data[n]=dres.data[n+1];
              dres.data[n+1]=dres.temp_data;
              flag=1;
            }
          }
          if(flag==0)
            break;
        }
        var s1="u";
        var s2="_div";
        var s3=450;
        var i;
        var sa1="d";
        var sa2=1;



        for(i=0;i<8;i++)
        {
          console.log();
          var idstring=s1+s3+s2;
          var namestring=sa1+sa2;
          var dydiv=document.getElementById(idstring);
          var naspan=document.getElementById(namestring);
          dydiv.src="http://129.204.247.165/"+dres.data[i].route;
          naspan.innerHTML=dres.data[i].title;
          if(dres.data[i].title.length>8)
            naspan.innerHTML=naspan.innerHTML.substring(0,8)+"...";
          s3=s3+1;
          sa2++;
        }



      }).catch(function (res) {
        console.log(res)
      })
    },
    destroyed:function()
    {
      clearInterval(inter1);
      clearInterval(inter2);
    }
  }

</script>

<style scoped>

</style>
